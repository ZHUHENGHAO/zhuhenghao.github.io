################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Libraries/love_quotes/love_quotes.c 

OBJS += \
./Libraries/love_quotes/love_quotes.o 

C_DEPS += \
./Libraries/love_quotes/love_quotes.d 


# Each subdirectory must supply rules for building sources it contributes
Libraries/love_quotes/%.o Libraries/love_quotes/%.su Libraries/love_quotes/%.cyclo: ../Libraries/love_quotes/%.c Libraries/love_quotes/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m3 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F103xB -c -I"F:/data/CubeIDE project/Xiaozhu_Epaper/Libraries/love_quotes" -I"F:/data/CubeIDE project/Xiaozhu_Epaper/Libraries/lunar" -I../Core/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy -I../Drivers/STM32F1xx_HAL_Driver/Inc -I../Drivers/CMSIS/Device/ST/STM32F1xx/Include -I../Drivers/CMSIS/Include -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM3 -I"F:/data/STM32Cube project/Xiaozhu_Epaper (2)/Xiaozhu_Epaper/Libraries/include" -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2 -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Libraries-2f-love_quotes

clean-Libraries-2f-love_quotes:
	-$(RM) ./Libraries/love_quotes/love_quotes.cyclo ./Libraries/love_quotes/love_quotes.d ./Libraries/love_quotes/love_quotes.o ./Libraries/love_quotes/love_quotes.su

.PHONY: clean-Libraries-2f-love_quotes

