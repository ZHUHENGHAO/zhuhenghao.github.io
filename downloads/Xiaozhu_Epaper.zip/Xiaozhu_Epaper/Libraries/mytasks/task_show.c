#include "myfreertos.h"

void show() {
	osSemaphoreAcquire(Binary_Sem_1Handle, osWaitForever);
	printf("��ǰʱ��:%d-%d-%d, %d:%d:%d \n",Time_now.year,Time_now.month,Time_now.day,Time_now.hour,Time_now.minute,Time_now.second);
//	HAL_GPIO_WritePin(IO_LED_GPIO_Port, IO_LED_Pin,
//			!HAL_GPIO_ReadPin(IO_LED_GPIO_Port, IO_LED_Pin));	//LED=0 ��
//	printf("vc02:%d\n",vc02_msg);
	osDelay(1000);
}

void init_show(){
	EPD_HW_Init(); 													//Electronic paper initialization

//	EPD_ALL_image(gImage1_white,gImage1_xiaowu);	//Refresh the picture in full screen

#ifdef scene1
#ifdef black_white_red
	EPD_WhiteScreen_Black();
	//EPD_WhiteScreen_White();
#else
	EPD_WhiteScreen_White();	
#endif

	EPD_W21_Init();
	//white
	EPD_Dis_Part(0, 0, gImage1_white, 296, 128, NEG);
	// �԰��ĺ�ɫͼ��
	EPD_Dis_Part_RED(160, 48, gImage_love, 32, 32, POS);
	// ÿ��һ�䣺
	EPD_Dis_Part (140, 85, mryj_Chinese12, 54, 16, NEG);
	// ��ʾÿ���黰 (����Ļ�ײ�)
	const char* quote = get_daily_quote(Time_now);
	EPD_Dis_string_8 (140, 103, 295, quote, NEG);


	EPD_Dis_Part(0, 0, photo3, 128, 128, POS);
////	EPD_Dis_Part(0, 0, photo4, 128, 128, POS);
////	EPD_Dis_Part(0, 0, photo6, 128, 128, POS);
////	EPD_Dis_Part(0, 0, photo7, 120, 120, POS);
	EPD_Part_Update_and_DeepSleep();
#endif


}

void update_show(int i)
{
	 EPD_W21_Init();
#ifdef scene1
	//white
//	 for(int i =0; i<1; i++)
	 {
	EPD_Dis_Part(0, 0, gImage1_white, 296, 128, NEG);
//	EPD_Part_Update_and_DeepSleep();
//	HAL_Delay(20);
	 }

	//right - ʱ�������
	EPD_Dis_string(145, 0, time, 32, NEG);
	EPD_Dis_string(160, 32, date, 16, NEG);

	// ÿ��һ�䣺
	EPD_Dis_Part (140, 85, mryj_Chinese12, 54, 16, NEG);
	// ��ʾÿ���黰 (����Ļ�ײ�)
	const char* quote = get_daily_quote(Time_now);
	EPD_Dis_string_8 (140, 103, 295, quote, NEG);
	
	// ��ʾ��ʱ��ͼ�����ֵ
//	EPD_Dis_Part_RED(160, 48, gImage_love, 32, 32, POS);
	EPD_Dis_string(160 + 32, 58, itoa(date_diff(Time_start, Time_now),temp_itoa,10), 16, NEG);

	switch(i%6)
	{
		case 0:
			//white
			EPD_Dis_Part(0, 0, photo1, 120, 120, POS);
			break;
		case 1:
			EPD_Dis_Part(0, 0, photo2, 120, 120, POS);
			break;
		case 2:
			EPD_Dis_Part(0, 0, photo3, 128, 128, POS);
			break;
		case 3:
			EPD_Dis_Part(0, 0, photo4, 128, 128, POS);
			break;
		case 4:
			EPD_Dis_Part(0, 0, photo6, 128, 128, POS);
			break;
		case 5:
			EPD_Dis_Part(0, 0, photo7, 120, 120, POS);
			break;
		default:
			break;
	}

#ifdef black_white_red

	if(date_flash == 1)
	{
	EPD_WhiteScreen_Black();
	}

#else
	EPD_WhiteScreen_White();	
#endif

	EPD_Part_Update_and_DeepSleep();



#endif


}
void update_photo()
{
	static int i=2;

	i++;

	switch(i%6)
	{
		case 0:
			//white
			EPD_Dis_Part(0, 0, photo1, 120, 120, POS);
			break;
		case 1:
			EPD_Dis_Part(0, 0, photo2, 120, 120, POS);
			break;
		case 2:
			EPD_Dis_Part(0, 0, photo3, 128, 128, POS);
			break;
		case 3:
			EPD_Dis_Part(0, 0, photo4, 128, 128, POS);
			break;
		case 4:
			EPD_Dis_Part(0, 0, photo6, 128, 128, POS);
			break;
		case 5:
			EPD_Dis_Part(0, 0, photo7, 120, 120, POS);
			break;
		default:
			break;
	}


	EPD_Part_Update_and_DeepSleep();
}




