#ifndef __OLED_H
#define __OLED_H

#include "stm32f10x.h"
#include "OLED.h"



// �����Դ滺����������ʵ��OLED�����޸ģ�
#define OLED_WIDTH   128
#define OLED_HEIGHT  64
#define OLED_PAGES   (OLED_HEIGHT/8)  // 64/8=8ҳ


void OLED_Init(void);
void OLED_Clear(void);
void OLED_ShowChar(uint8_t Line, uint8_t Column, char Char);
void OLED_ShowString(uint8_t Line, uint8_t Column, char *String);
void OLED_ShowNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);
void OLED_ShowSignedNum(uint8_t Line, uint8_t Column, int32_t Number, uint8_t Length);
void OLED_ShowHexNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);
void OLED_ShowBinNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);
void OLED_ShowFNum(uint8_t Line, uint8_t Column, float Number, uint8_t Length, uint8_t FLength);
void OLED_ShowCC_F16x16(uint8_t Line, uint8_t Column, uint8_t num);
void OLED_I2C_Init(void);

void OLED_AllLine(void);
void OLED_ShowBMP(unsigned char x0,unsigned char y0,unsigned char x1,unsigned char y1);

void OLED_HorizontalLine(void);//ˮƽ��
void OLED_VerticalLine(void);//��ֱ��
void OLED_LsatlLine(void);//���ˮƽ��
void OLED_ShowChar_LastLine(uint8_t Line, uint8_t Column, char Char);
void OLED_ShowFNum_LastLine(uint8_t Line, uint8_t Column, float Number, uint8_t Length, uint8_t FLength);
void OLED_ShowChar6x8(uint8_t Line, uint8_t Column, char Char);
void OLED_ShowString6x8(uint8_t Line, uint8_t Column, char *String);
void OLED_ClearLine(uint8_t line);
void OLED_Full(void);


void OLED_Refresh(void) ;
void OLED_DrawPoint(uint8_t x, uint8_t y, uint8_t color) ;

#endif
