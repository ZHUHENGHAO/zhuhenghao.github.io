#include "stm32f10x.h"
#include "OLED_Font.h"
#include "OLED.h"
#include <stdio.h>
#include "string.h"

/*引脚配置*/
#define OLED_W_SCL(x)		GPIO_WriteBit(GPIOB, GPIO_Pin_8, (BitAction)(x))
#define OLED_W_SDA(x)		GPIO_WriteBit(GPIOB, GPIO_Pin_9, (BitAction)(x))


 
uint8_t CD_OLED_F8x16[95][16];
uint8_t CE_OLED_F8x16[95][16];
/*引脚初始化*/
void OLED_I2C_Init(void)
{
 	GPIO_InitTypeDef GPIO_InitStructure;
 
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
 	GPIO_Init(GPIOB, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
 	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	OLED_W_SCL(1);
	OLED_W_SDA(1);
}

/**
  * @brief  I2C开始
  * @param  无
  * @retval 无
  */
void OLED_I2C_Start(void)
{
	OLED_W_SDA(1);
	OLED_W_SCL(1);
	OLED_W_SDA(0);
	OLED_W_SCL(0);
}

/**
  * @brief  I2C停止
  * @param  无
  * @retval 无
  */
void OLED_I2C_Stop(void)
{
	OLED_W_SDA(0);
	OLED_W_SCL(1);
	OLED_W_SDA(1);
}

/**
  * @brief  I2C发送一个字节
  * @param  Byte 要发送的一个字节
  * @retval 无
  */
void OLED_I2C_SendByte(uint8_t Byte)
{
	uint8_t i;
	for (i = 0; i < 8; i++)
	{
		OLED_W_SDA(Byte & (0x80 >> i));//把Byte数据从高位开始一位一位的发送出去
		OLED_W_SCL(1);
		OLED_W_SCL(0);//下降沿的时候发送出去
	}
	OLED_W_SCL(1);	//额外的一个时钟，不处理应答信号
	OLED_W_SCL(0);
}

/**
  * @brief  OLED写命令
  * @param  Command 要写入的命令
  * @retval 无
  */
void OLED_WriteCommand(uint8_t Command)
{
	OLED_I2C_Start();
	OLED_I2C_SendByte(0x78);		//从机地址
	OLED_I2C_SendByte(0x00);		//写命令
	OLED_I2C_SendByte(Command); 
	OLED_I2C_Stop();
}

/**
  * @brief  OLED写数据
  * @param  Data 要写入的数据
  * @retval 无
  */
void OLED_WriteData(uint8_t Data)
{
	OLED_I2C_Start();
	OLED_I2C_SendByte(0x78);		//从机地址
	OLED_I2C_SendByte(0x40);		//写数据
	OLED_I2C_SendByte(Data);
	OLED_I2C_Stop();
}

/**
  * @brief  OLED设置光标位置
  * @param  Y 以左上角为原点，向下方向的坐标，范围：0~7
  * @param  X 以左上角为原点，向右方向的坐标，范围：0~127
  * @retval 无
  */
void OLED_SetCursor(uint8_t Y, uint8_t X)
{
	OLED_WriteCommand(0xB0 | Y);					//设置Y位置
	OLED_WriteCommand(0x10 | ((X & 0xF0) >> 4));	//设置X位置高4位
	OLED_WriteCommand(0x00 | (X & 0x0F));			//设置X位置低4位
}



extern uint8_t OLED_GRAM[OLED_PAGES][OLED_WIDTH];  // 8页x128列

void OLED_Refresh(void) 
{
    for(uint8_t page=0; page<OLED_PAGES; page++) {
        OLED_SetCursor(page, 0); // 设置到当前页的起始位置
        
        // 发送当前页的128列数据
        for(uint8_t col=0; col<OLED_WIDTH; col++) {
            OLED_WriteData(OLED_GRAM[page][col]);
        }
    }
}

// 绘制像素点（核心函数）
void OLED_DrawPoint(uint8_t x, uint8_t y, uint8_t color) 
{
    // 硬件边界检查
    if(x >= OLED_WIDTH || y >= OLED_HEIGHT) return;
    
    // 计算页和位
    uint8_t page = y / 8;       // 确定所在页（0-7）
    uint8_t bit_pos = y % 8;    // 页内的具体bit位置
    
    // 修改显存缓冲区
    if(color) {
        OLED_GRAM[page][x] |= (1 << bit_pos);   // 点亮像素
    } else {
        OLED_GRAM[page][x] &= ~(1 << bit_pos);  // 熄灭像素
    }
//		OLED_Refresh();
}

// 清屏函数（优化）
void OLED_Clear(void) 
{
    memset(OLED_GRAM, 0, sizeof(OLED_GRAM));
    OLED_Refresh();
}

///**
//  * @brief  OLED清屏
//  * @param  无
//  * @retval 无
//  */
//void OLED_Clear(void)
//{  
//	uint8_t i, j;
//	for (j = 0; j < 8; j++)
//	{
//		OLED_SetCursor(j, 0);
//		for(i = 0; i < 128; i++)
//		{
//			OLED_WriteData(0x00);
//		}
//	}
//}

/**
  * @brief  OLED清屏
  * @param  无
  * @retval 无
  */
void OLED_Full(void)
{  
	uint8_t i, j;
	for (j = 0; j < 8; j++)
	{
		OLED_SetCursor(j, 0);
		for(i = 0; i < 128; i++)
		{
			OLED_WriteData(0xFF);
		}
	}
}
/**
  * @brief  清除OLED指定行
  * @param  line: 要清除的行号（范围 1~8）
  * @retval 无
  */
void OLED_ClearLine(uint8_t line)
{
    if (line < 1 || line > 8)  // 行号范围限制（假设屏幕共8行）
        return;

    uint8_t page = line - 1;   // 将行号转换为页号（0~7）
    OLED_SetCursor(page, 0);   // 设置光标到目标页的起始列（0列）

    // 清除该行所有列（共128列）
    for (uint8_t i = 0; i < 128; i++)
    {
        OLED_WriteData(0x00);  // 写入0x00清除像素
    }
}

/**
  * @brief  OLED显示一个字符
  * @param  Line 行位置，范围：1~4
  * @param  Column 列位置，范围：1~16
  * @param  Char 要显示的一个字符，范围：ASCII可见字符
  * @retval 无
  */
void OLED_ShowChar(uint8_t Line, uint8_t Column, char Char)
{      	
	uint8_t i;
//	OLED_HorizontalLine();
	OLED_SetCursor((Line - 1) * 2, (Column - 1) * 8);		//设置光标位置在上半部分
	for (i = 0; i < 8; i++)
	{
		OLED_WriteData(OLED_F8x16[Char - ' '][i]);			//显示上半部分内容
	}
	OLED_SetCursor((Line - 1) * 2 + 1, (Column - 1) * 8);	//设置光标位置在下半部分
	for (i = 0; i < 8; i++)
	{
		OLED_WriteData(OLED_F8x16[Char - ' '][i + 8]);		//显示下半部分内容
	}
}
/**
  * @brief  OLED显示一个6x8字符
  * @param  Line 行位置，范围：1~8
  * @param  Column 列位置，范围：1~16
  * @param  Char 要显示的一个字符，范围：ASCII可见字符
  * @retval 无
  */
void OLED_ShowChar6x8(uint8_t Line, uint8_t Column, char Char)
{	//传入参数 x,y分别表示列和页  Char表示字符
	unsigned char i,c;
	
	c = Char - ' '; //减掉space空格的ASCII码，的到字符的偏移量

	
	OLED_SetCursor((Line - 1), (Column - 1) * 8);		//设置光标位置在上半部分
	
	for(i=0;i<6;i++) //8*16 写上一半
	{
		OLED_WriteData(F6x8[c][i]); //c*16 从空格开始的偏移量，+i 偏移到第i个数据
	}
	

}

/**
  * @brief  OLED显示字符串
  * @param  Line 起始行位置，范围：1~4
  * @param  Column 起始列位置，范围：1~16
  * @param  String 要显示的字符串，范围：ASCII可见字符
  * @retval 无
  */
void OLED_ShowString(uint8_t Line, uint8_t Column, char *String)
{
	uint8_t i;
	for (i = 0; String[i] != '\0'; i++)
	{
		OLED_ShowChar(Line, Column + i, String[i]);
	}
}
/**
  * @brief  OLED显示6x8字符串
  * @param  Line 起始行位置，范围：1~8
  * @param  Column 起始列位置，范围：1~16
  * @param  String 要显示的字符串，范围：ASCII可见字符
  * @retval 无
  */
void OLED_ShowString6x8(uint8_t Line, uint8_t Column, char *String)
{
	uint8_t i;
	for (i = 0; String[i] != '\0'; i++)
	{
		OLED_ShowChar6x8(Line, Column + i, String[i]);
	}
}
/**
  * @brief  OLED次方函数
  * @retval 返回值等于X的Y次方
  */
uint32_t OLED_Pow(uint32_t X, uint32_t Y)
{
	uint32_t Result = 1;
	while (Y--)
	{
		Result *= X;
	}
	return Result;
}

/**
  * @brief  OLED显示数字（十进制，正数）
  * @param  Line 起始行位置，范围：1~4
  * @param  Column 起始列位置，范围：1~16
  * @param  Number 要显示的数字，范围：0~4294967295
  * @param  Length 要显示数字的长度，范围：1~10
  * @retval 无
  */
void OLED_ShowNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length)
{
	uint8_t i;
	for (i = 0; i < Length; i++)							
	{
		OLED_ShowChar(Line, Column + i, Number / OLED_Pow(10, Length - i - 1) % 10 + '0');
	}
}

/**
  * @brief  OLED显示数字（十进制，带符号数）
  * @param  Line 起始行位置，范围：1~4
  * @param  Column 起始列位置，范围：1~16
  * @param  Number 要显示的数字，范围：-2147483648~2147483647
  * @param  Length 要显示数字的长度，范围：1~10
  * @retval 无
  */
void OLED_ShowSignedNum(uint8_t Line, uint8_t Column, int32_t Number, uint8_t Length)
{
	uint8_t i;
	uint32_t Number1;
	if (Number >= 0)
	{
		OLED_ShowChar(Line, Column, '+');
		Number1 = Number;
	}
	else
	{
		OLED_ShowChar(Line, Column, '-');
		Number1 = -Number;
	}
	for (i = 0; i < Length; i++)							
	{
		OLED_ShowChar(Line, Column + i + 1, Number1 / OLED_Pow(10, Length - i - 1) % 10 + '0');
	}
}

/**
  * @brief  OLED显示数字（十六进制，正数）
  * @param  Line 起始行位置，范围：1~4
  * @param  Column 起始列位置，范围：1~16
  * @param  Number 要显示的数字，范围：0~0xFFFFFFFF
  * @param  Length 要显示数字的长度，范围：1~8
  * @retval 无
  */
void OLED_ShowHexNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length)
{
	uint8_t i, SingleNumber;
	for (i = 0; i < Length; i++)							
	{
		SingleNumber = Number / OLED_Pow(16, Length - i - 1) % 16;
		if (SingleNumber < 10)
		{
			OLED_ShowChar(Line, Column + i, SingleNumber + '0');
		}
		else
		{
			OLED_ShowChar(Line, Column + i, SingleNumber - 10 + 'A');
		}
	}
}

/**
  * @brief  OLED显示数字（二进制，正数）
  * @param  Line 起始行位置，范围：1~4
  * @param  Column 起始列位置，范围：1~16
  * @param  Number 要显示的数字，范围：0~1111 1111 1111 1111
  * @param  Length 要显示数字的长度，范围：1~16
  * @retval 无
  */
void OLED_ShowBinNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length)
{
	uint8_t i;
	for (i = 0; i < Length; i++)							
	{
		OLED_ShowChar(Line, Column + i, Number / OLED_Pow(2, Length - i - 1) % 2 + '0');
	}
}

/**
  * @brief  OLED初始化
  * @param  无
  * @retval 无
  */
void OLED_Init(void)
{
	uint32_t i, j;
	
	for (i = 0; i < 1000; i++)			//上电延时
	{
		for (j = 0; j < 1000; j++);
	}
	
	OLED_I2C_Init();			//端口初始化
	
	OLED_WriteCommand(0xAE);	//关闭显示
	
	OLED_WriteCommand(0xD5);	//设置显示时钟分频比/振荡器频率
	OLED_WriteCommand(0x80);
	
	OLED_WriteCommand(0xA8);	//设置多路复用率
	OLED_WriteCommand(0x3F);
	
	OLED_WriteCommand(0xD3);	//设置显示偏移
	OLED_WriteCommand(0x00);
	
	OLED_WriteCommand(0x40);	//设置显示开始行
	
	OLED_WriteCommand(0xA1);	//设置左右方向，0xA1正常 0xA0左右反置
	
	OLED_WriteCommand(0xC8);	//设置上下方向，0xC8正常 0xC0上下反置

	OLED_WriteCommand(0xDA);	//设置COM引脚硬件配置
	OLED_WriteCommand(0x12);
	
	OLED_WriteCommand(0x81);	//设置对比度控制
	OLED_WriteCommand(0xCF);

	OLED_WriteCommand(0xD9);	//设置预充电周期
	OLED_WriteCommand(0xF1);

	OLED_WriteCommand(0xDB);	//设置VCOMH取消选择级别
	OLED_WriteCommand(0x30);

	OLED_WriteCommand(0xA4);	//设置整个显示打开/关闭

	OLED_WriteCommand(0xA6);	//设置正常/倒转显示

	OLED_WriteCommand(0x8D);	//设置充电泵
	OLED_WriteCommand(0x14);

	OLED_WriteCommand(0xAF);	//开启显示
		
	OLED_Clear();				//OLED清屏
}
//Line 1-4 表示行
//Column 1-16 表示列
//Number 表示显示的数字
//Length 表示数字的总个数
//FLength 表示小数点后数字的个数
void OLED_ShowFNum(uint8_t Line, uint8_t Column, float Number, uint8_t Length, uint8_t FLength)
{
	uint8_t i;
	uint8_t flag = 1; // 标志是否为小数部分
	float Number1;
	uint32_t Number2;
	if (Number >= 0)
	{
		OLED_ShowChar(Line, Column, '+');
		Number1 = Number;
	}
	else
	{
		OLED_ShowChar(Line, Column, '-');
		Number1 = -Number;
	}
	Number2 = (int)(Number1*OLED_Pow(10, FLength)); // 小数转换成整数
	for(i = Length; i > 0; i--)
	{
		if(i == Length - FLength)
		{
			OLED_ShowChar(Line, Column + i + flag, '.');
			flag = 0;
		}
		OLED_ShowChar(Line, Column + i + flag, Number2/OLED_Pow(10, Length-i)%10+'0');
	}
}


void OLED_VerticalLine(void)//垂直线
{
		uint8_t  j;
	

	for (j = 0; j <8; j++)
	{
		OLED_SetCursor(j, 0);
		OLED_WriteData(0xff);
		OLED_SetCursor(j, 127);
		OLED_WriteData(0xff);	
	}


}


void OLED_ShowChar_LastLine(uint8_t Line, uint8_t Column, char Char)
{      	
	uint8_t i;
//	OLED_HorizontalLine();
	OLED_SetCursor((Line - 1) * 2, (Column - 1) * 8);		//设置光标位置在上半部分
	for (i = 0; i < 8; i++)
	{
		OLED_WriteData(CE_OLED_F8x16[Char - ' '][i]);			//显示上半部分内容
	}
	OLED_SetCursor((Line - 1) * 2 + 1, (Column - 1) * 8);	//设置光标位置在下半部分
	for (i = 0; i < 8; i++)
	{
		OLED_WriteData(CE_OLED_F8x16[Char - ' '][i + 8]);		//显示下半部分内容
	}
}


void OLED_ShowFNum_LastLine(uint8_t Line, uint8_t Column, float Number, uint8_t Length, uint8_t FLength)
{
	uint8_t i;
	uint8_t flag = 1; // 标志是否为小数部分
	float Number1;
	uint32_t Number2;
	if (Number >= 0)
	{
		OLED_ShowChar_LastLine(Line, Column, '+');
		Number1 = Number;
	}
	else
	{
		OLED_ShowChar_LastLine(Line, Column, '-');
		Number1 = -Number;
	}
	Number2 = (int)(Number1*OLED_Pow(10, FLength)); // 小数转换成整数
	for(i = Length; i > 0; i--)
	{
		if(i == Length - FLength)
		{
			OLED_ShowChar_LastLine(Line, Column + i + flag, '.');
			flag = 0;
		}
		OLED_ShowChar_LastLine(Line, Column + i + flag, Number2/OLED_Pow(10, Length-i)%10+'0');
	}
}
void OLED_ShowBMP(unsigned char x0,unsigned char y0,unsigned char x1,unsigned char y1)
{
		unsigned char x,y;
		unsigned int j = 0;
		
		if(y1 % 8 == 0)
		{
				y = y1 / 8;
		}
		else
		{
				y = y1 / 8+1;
		}
		
		for(y=y0;y<y1;y++)
		{
				OLED_SetCursor(y,x0);

				for(x=x0;x<x1;x++)
				{
						OLED_WriteData(BMP[j++]);
				}
		}
}


